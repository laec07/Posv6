

<div class="tw-mt-auto">
  <div class="tw-mb-4 tw-ms-8 -tw-mt-1 no-print">
    <p class="tw-text-xs tw-font-normal tw-text-gray-500">
      <?php echo e(config('app.name', 'ultimatePOS'), false); ?> - <span class="tw-font-mono tw-font-medium"> V<?php echo e(config('author.app_version'), false); ?></span> | Copyright &copy; <?php echo e(date('Y'), false); ?> All rights reserved.
    </p>
  </div>
</div><?php /**PATH C:\DES\posv6\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>